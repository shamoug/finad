﻿Finad 1.2.0

Double-click install.bat. It installs Finad for you (no admin rights), adds Start Menu and Desktop shortcuts, and starts it.
Finad then starts with Windows and keeps reading the news from the system tray.

https://shamoug.github.io/finad/
